
<form action="<?php echo e(route('api.save.student')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
    <input type="file" name="files[]" id="file" multiple>
<button>Save</button>
</form>
<?php /**PATH I:\Web_Development_Work\cslab-app\cms\resources\views/test.blade.php ENDPATH**/ ?>