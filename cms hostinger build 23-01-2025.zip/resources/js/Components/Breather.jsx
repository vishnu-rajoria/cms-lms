export default function Breather() {
    return (
        <div
            title="beath and release"
            className="breather bg-pink-300 dark:bg-pink-400 w-[20px] h-[20px] rounded-full mx-4 my-4 breath"
        ></div>
    );
}
