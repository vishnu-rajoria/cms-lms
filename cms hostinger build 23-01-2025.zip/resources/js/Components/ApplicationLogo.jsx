export default function ApplicationLogo(props) {
    return (
        <>
            <img
                className="w-[150px]"
                src="https://mliekvpsfk1b.i.optimole.com/w:1920/h:640/q:mauto/ig:avif/https://cslab.in/wp-content/uploads/2024/01/CSLAB-Logo-2023.svg"
                alt=""
            />
        </>
    );
}
