export const baseURL = import.meta.env.VITE_APP_URL;
