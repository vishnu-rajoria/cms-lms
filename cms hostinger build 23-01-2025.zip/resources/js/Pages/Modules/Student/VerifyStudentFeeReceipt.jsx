import { getStudentImageURL } from "@/Helpers/ImageHelper";
import { formattedMysqlDateAndTime } from "@/Helpers/TimeHelper";
export default function VerifyStudentFeeReceipt({
    verificationResponseData,
    ...props
}) {
    return (
        <>
            {verificationResponseData.is_fee_verified ? (
                <div class="w-screen h-screen grid place-content-center bg-green-100 p-2 bg-[url('https://mliekvpsfk1b.i.optimole.com/w:auto/h:auto/q:mauto/ig:avif/https://cslab.in/wp-content/uploads/2024/02/CSLAB-Logo-2024.png')] bg-[length:40px_15px]">
                    <div class="receipt-details  shadow-lg rounded-md overflow-hidden bg-white">
                        <h1 class="bg-green-900 text-green-100 p-2 flex justify-between items-center">
                            Receipt is verified successfully
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="20px"
                                height="20px"
                                viewBox="0 0 24 24"
                                fill="none"
                            >
                                <path
                                    d="M4.91988 12.257C4.2856 12.257 3.65131 12.5199 3.19988 13.0342C2.79417 13.4913 2.59417 14.0799 2.63417 14.6913C2.67417 15.3027 2.94846 15.857 3.4056 16.2627L7.51417 19.8684C7.93131 20.2342 8.46846 20.4399 9.02274 20.4399C9.0856 20.4399 9.14846 20.4399 9.21131 20.4342C9.82846 20.3827 10.4056 20.0799 10.7942 19.5999L20.857 7.27986C21.657 6.30272 21.5085 4.85701 20.5313 4.05701C20.057 3.67415 19.4627 3.49129 18.857 3.55415C18.2513 3.61701 17.7027 3.90844 17.3142 4.38272L8.74846 14.8627L6.42274 12.8227C5.99417 12.4456 5.45131 12.257 4.91988 12.257Z"
                                    fill="url(#paint0_linear)"
                                />
                                <path
                                    d="M9.02279 20.0284C8.56565 20.0284 8.12565 19.8627 7.78279 19.5598L3.67422 15.9541C2.89708 15.2684 2.81708 14.0798 3.50279 13.3027C4.18851 12.5255 5.37708 12.4455 6.15422 13.1313L8.79994 15.4513L17.6285 4.63983C18.2856 3.83412 19.4685 3.71983 20.2742 4.37126C21.0799 5.0284 21.1942 6.21126 20.5428 7.01697L10.4742 19.337C10.1542 19.7313 9.67993 19.977 9.17708 20.0227C9.12565 20.0227 9.07422 20.0284 9.02279 20.0284Z"
                                    fill="url(#paint1_linear)"
                                />
                                <path
                                    opacity="0.75"
                                    d="M9.02279 20.0284C8.56565 20.0284 8.12565 19.8627 7.78279 19.5598L3.67422 15.9541C2.89708 15.2684 2.81708 14.0798 3.50279 13.3027C4.18851 12.5255 5.37708 12.4455 6.15422 13.1313L8.79994 15.4513L17.6285 4.63983C18.2856 3.83412 19.4685 3.71983 20.2742 4.37126C21.0799 5.0284 21.1942 6.21126 20.5428 7.01697L10.4742 19.337C10.1542 19.7313 9.67993 19.977 9.17708 20.0227C9.12565 20.0227 9.07422 20.0284 9.02279 20.0284Z"
                                    fill="url(#paint2_radial)"
                                />
                                <path
                                    opacity="0.5"
                                    d="M9.02279 20.0284C8.56565 20.0284 8.12565 19.8627 7.78279 19.5598L3.67422 15.9541C2.89708 15.2684 2.81708 14.0798 3.50279 13.3027C4.18851 12.5255 5.37708 12.4455 6.15422 13.1313L8.79994 15.4513L17.6285 4.63983C18.2856 3.83412 19.4685 3.71983 20.2742 4.37126C21.0799 5.0284 21.1942 6.21126 20.5428 7.01697L10.4742 19.337C10.1542 19.7313 9.67993 19.977 9.17708 20.0227C9.12565 20.0227 9.07422 20.0284 9.02279 20.0284Z"
                                    fill="url(#paint3_radial)"
                                />
                                <defs>
                                    <linearGradient
                                        id="paint0_linear"
                                        x1="15.825"
                                        y1="-13.9667"
                                        x2="9.82533"
                                        y2="23.9171"
                                        gradientUnits="userSpaceOnUse"
                                    >
                                        <stop stop-color="#00CC00" />
                                        <stop
                                            offset="0.1878"
                                            stop-color="#06C102"
                                        />
                                        <stop
                                            offset="0.5185"
                                            stop-color="#17A306"
                                        />
                                        <stop
                                            offset="0.9507"
                                            stop-color="#33740C"
                                        />
                                        <stop offset="1" stop-color="#366E0D" />
                                    </linearGradient>
                                    <linearGradient
                                        id="paint1_linear"
                                        x1="15.2501"
                                        y1="0.625426"
                                        x2="7.43443"
                                        y2="23.6215"
                                        gradientUnits="userSpaceOnUse"
                                    >
                                        <stop
                                            offset="0.2544"
                                            stop-color="#90D856"
                                        />
                                        <stop
                                            offset="0.736"
                                            stop-color="#00CC00"
                                        />
                                        <stop
                                            offset="0.7716"
                                            stop-color="#0BCD07"
                                        />
                                        <stop
                                            offset="0.8342"
                                            stop-color="#29CF18"
                                        />
                                        <stop
                                            offset="0.9166"
                                            stop-color="#59D335"
                                        />
                                        <stop offset="1" stop-color="#90D856" />
                                    </linearGradient>
                                    <radialGradient
                                        id="paint2_radial"
                                        cx="0"
                                        cy="0"
                                        r="1"
                                        gradientUnits="userSpaceOnUse"
                                        gradientTransform="translate(15.452 8.95803) rotate(116.129) scale(8.35776 4.28316)"
                                    >
                                        <stop
                                            stop-color="#FBE07A"
                                            stop-opacity="0.75"
                                        />
                                        <stop
                                            offset="0.0803394"
                                            stop-color="#FBE387"
                                            stop-opacity="0.6897"
                                        />
                                        <stop
                                            offset="0.5173"
                                            stop-color="#FDF2C7"
                                            stop-opacity="0.362"
                                        />
                                        <stop
                                            offset="0.8357"
                                            stop-color="#FFFBF0"
                                            stop-opacity="0.1233"
                                        />
                                        <stop
                                            offset="1"
                                            stop-color="white"
                                            stop-opacity="0"
                                        />
                                    </radialGradient>
                                    <radialGradient
                                        id="paint3_radial"
                                        cx="0"
                                        cy="0"
                                        r="1"
                                        gradientUnits="userSpaceOnUse"
                                        gradientTransform="translate(11.6442 17.0245) rotate(155.316) scale(9.80163 4.14906)"
                                    >
                                        <stop
                                            stop-color="#440063"
                                            stop-opacity="0.25"
                                        />
                                        <stop
                                            offset="1"
                                            stop-color="#420061"
                                            stop-opacity="0"
                                        />
                                    </radialGradient>
                                </defs>
                                <script xmlns="" />
                            </svg>
                        </h1>
                        <div className="student-details flex-col flex gap-4 p-6 items-center">
                            <img
                                className="rounded-full w-[100px] h-[100px]"
                                src={getStudentImageURL(
                                    verificationResponseData.studentDetails.id,
                                    verificationResponseData.studentDetails
                                        .profile_pic
                                )}
                                alt=""
                            />
                            <div class="details">
                                <p>
                                    <span className="font-bold">
                                        Student Name :
                                    </span>
                                    {
                                        verificationResponseData.studentDetails
                                            .name
                                    }
                                </p>
                                <p>
                                    <span className="font-bold">
                                        Father's Name :
                                    </span>
                                    {
                                        verificationResponseData.studentDetails
                                            .student_details.fname
                                    }
                                </p>
                                <p>
                                    <span className="font-bold">
                                        Date of Joining :
                                    </span>
                                    {
                                        formattedMysqlDateAndTime(
                                            verificationResponseData
                                                .studentDetails.student_details
                                                .doj
                                        ).split(" / ")[0]
                                    }
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <div class="w-screen h-screen grid place-content-center bg-red-100 p-2 bg-[url('https://mliekvpsfk1b.i.optimole.com/w:auto/h:auto/q:mauto/ig:avif/https://cslab.in/wp-content/uploads/2024/02/CSLAB-Logo-2024.png')] bg-[length:40px_15px]">
                    <div class="receipt-details  shadow-lg rounded-md overflow-hidden bg-white">
                        <h1 class="bg-red-900 text-red-100 p-2  gap-2 flex justify-between items-centera">
                            Receipt verified failed
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                width="20px"
                                height="20px"
                                viewBox="0 0 64 64"
                                aria-hidden="true"
                                role="img"
                                class="iconify iconify--emojione"
                                preserveAspectRatio="xMidYMid meet"
                            >
                                <path
                                    fill="#ff5a79"
                                    d="M62 10.6L53.4 2L32 23.4L10.6 2L2 10.6L23.4 32L2 53.4l8.6 8.6L32 40.6L53.4 62l8.6-8.6L40.6 32z"
                                />
                                <script xmlns="" />
                            </svg>
                        </h1>
                    </div>
                </div>
            )}
        </>
    );
}
