<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EventBroadcastController extends Controller
{
    function broadcastNotification()
    {
        
    }
}
