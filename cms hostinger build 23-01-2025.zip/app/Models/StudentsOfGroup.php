<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentsOfGroup extends Model
{
    // table to be use
    protected $table = "students_of_groups";
    // nothing to be guared | all fields are mass assignable
    protected $guarded = [];
}
